# Little Lemon Restaurant Booking App
Author: SHAIK RABIYA ALBASARI

## Description
A React app for booking tables at Little Lemon restaurant with form validation and confirmation.

## How to Run
1. Run `npm install`
2. Run `npm start`
3. Open http://localhost:3000
