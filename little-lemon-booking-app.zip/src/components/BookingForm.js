import React, { useState } from 'react';
function BookingForm() {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Booking confirmed for ${name} on ${date} at ${time}`);
  };
  return (
    <form onSubmit={handleSubmit}>
      <h2>Book a Table</h2>
      <label>Name:</label>
      <input value={name} onChange={(e) => setName(e.target.value)} required />
      <label>Date:</label>
      <input type='date' value={date} onChange={(e) => setDate(e.target.value)} required />
      <label>Time:</label>
      <input type='time' value={time} onChange={(e) => setTime(e.target.value)} required />
      <button type='submit'>Confirm Booking</button>
    </form>
  );
}
export default BookingForm;