import React from 'react';
import BookingPage from './pages/BookingPage';
function App() {
  return <BookingPage />;
}
export default App;